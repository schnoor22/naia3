# Static Assets

Place the NAIA logo here as `logo.png`.

The logo will be served at `/logo.png` from the SvelteKit app.
