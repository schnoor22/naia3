import{l as o,a as r}from"../chunks/BRfGlFTE.js";export{o as load_css,r as start};
//# sourceMappingURL=start.2En4IB31.js.map
