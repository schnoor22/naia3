import{t as y}from"./itmToP9i.js";import{N as r}from"./DnfnuaTU.js";function n(t,e,f,i){var l=t.__style;if(r||l!==e){var s=y(e);(!r||s!==t.getAttribute("style"))&&(s==null?t.removeAttribute("style"):t.style.cssText=s),t.__style=e}return i}export{n as s};
//# sourceMappingURL=pPaBNNUB.js.map
